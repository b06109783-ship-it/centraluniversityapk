Central University app (blue & white, logo included)
Build APK: open this folder in Android Studio -> Build > Build APK(s)
  or run: gradle assembleDebug -> app/build/outputs/apk/debug/app-debug.apk
UI lives in app/src/main/assets/index.html (also opens in a phone browser).
Demo staff login: staff@cu.edu / staff123

No Android Studio? Upload this folder to a new GitHub repository (keep the .github folder).
Open the Actions tab -> "Build APK" -> download "CentralUniversity-APK" (contains app-debug.apk).
On the phone: copy the APK over, tap it, and allow "Install unknown apps" when asked.
